#!/bin/bash

N=2

cat interfaces-tmp > interfaces

while [ "$N" -le 99 ]
do

cat << EOL >> interfaces

auto ens3:$N
iface ens3:$N inet static
    address 102.120.$N.2/30
iface ens3:$N inet6 static
    address 4d0c:120:0:$N::2/126
EOL

(( N++ ))

done